import { MatchPassword } from './match-password';

describe('MatchPassword', () => {
  it('should create an instance', () => {
    expect(new MatchPassword()).toBeTruthy();
  });
});
