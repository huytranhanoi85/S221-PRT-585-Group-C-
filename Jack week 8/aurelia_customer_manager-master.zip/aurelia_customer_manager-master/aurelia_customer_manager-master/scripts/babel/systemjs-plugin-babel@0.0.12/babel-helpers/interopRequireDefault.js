export default (function (obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
})