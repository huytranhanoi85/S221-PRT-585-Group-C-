export interface Log {
  id: string,
  text: string,
  date: any
}