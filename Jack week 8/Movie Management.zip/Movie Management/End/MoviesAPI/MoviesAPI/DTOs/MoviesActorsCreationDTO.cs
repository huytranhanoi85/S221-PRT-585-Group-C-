﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoviesAPI.DTOs
{
    public class MoviesActorsCreationDTO
    {
        public int Id { get; set; }
        public string Character { get; set; }
    }
}
