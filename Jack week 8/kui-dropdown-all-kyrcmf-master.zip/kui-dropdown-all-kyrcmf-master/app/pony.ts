export interface Pony {
  id: number;
  name: string;
  avatar?: string;
  alias?: string;
  sex?: string;
  url?: string;
  occupation?: string;
  residence?: string;
  kind?: any;
  image?: any;
}