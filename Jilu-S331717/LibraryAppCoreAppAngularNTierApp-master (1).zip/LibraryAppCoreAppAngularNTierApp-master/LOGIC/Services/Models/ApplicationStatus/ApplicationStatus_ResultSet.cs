﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LOGIC.Services.Models.ApplicationStatus
{
    public class ApplicationStatus_ResultSet
    {
        public Int64 status_id { get; set; } //(PK)
        public String name { get; set; }
    }
}
