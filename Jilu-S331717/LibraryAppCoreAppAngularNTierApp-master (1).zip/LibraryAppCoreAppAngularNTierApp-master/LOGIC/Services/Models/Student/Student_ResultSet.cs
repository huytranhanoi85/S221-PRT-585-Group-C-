﻿using System;

namespace LOGIC.Services.Models.Student
{
    public class Student_ResultSet
    {
        public Int64 student_id { get; set; }
        public String name { get; set; }
    }
}