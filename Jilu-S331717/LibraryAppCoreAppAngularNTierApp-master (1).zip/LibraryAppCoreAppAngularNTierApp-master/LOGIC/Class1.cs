﻿using System;

namespace LOGIC
{
    public class Class1
    {
    }
}
