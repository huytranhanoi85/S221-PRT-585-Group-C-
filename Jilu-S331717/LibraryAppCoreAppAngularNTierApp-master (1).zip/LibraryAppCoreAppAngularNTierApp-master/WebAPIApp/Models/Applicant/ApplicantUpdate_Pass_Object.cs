﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_API.Models.Applicant
{
    public class ApplicantUpdate_Pass_Object: Applicant_Pass_Object
    {
        public int id { get; set; }
    }
}
