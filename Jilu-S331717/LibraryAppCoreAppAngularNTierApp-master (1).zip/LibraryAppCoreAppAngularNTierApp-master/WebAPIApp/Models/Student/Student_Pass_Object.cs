﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_API.Models.Student
{
    public class Student_Pass_Object
    {
        public int id { get; set; }
        public string name { get; set; }
      
    }
}
