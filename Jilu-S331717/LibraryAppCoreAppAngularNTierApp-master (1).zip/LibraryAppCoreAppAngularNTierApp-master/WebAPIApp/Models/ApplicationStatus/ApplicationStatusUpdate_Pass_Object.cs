﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_API.Models.ApplicationStatus
{
    public class ApplicationStatusUpdate_Pass_Object: ApplicationStatus_Pass_Object
    {
        public int id { get; set; }
    }
}
