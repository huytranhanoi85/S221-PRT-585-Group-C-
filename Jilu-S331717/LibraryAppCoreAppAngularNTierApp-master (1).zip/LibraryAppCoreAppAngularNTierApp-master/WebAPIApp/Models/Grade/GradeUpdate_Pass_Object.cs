﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WEB_API.Models.Grade
{
    public class GradeUpdate_Pass_Object: Grade_Pass_Object
    {
        public int id { get; set; }
    }
}
