export interface genreCreationDTO {
    name: string;
}