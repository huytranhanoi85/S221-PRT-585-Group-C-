import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-actors',
  templateUrl: './index-actors.component.html',
  styleUrls: ['./index-actors.component.css']
})
export class IndexActorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
